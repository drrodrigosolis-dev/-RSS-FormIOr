utils::globalVariables(c("column", "max_distinct", "preview", "row_number", "slice"))
