## ----eval = FALSE-------------------------------------------------------------
# handbook <- system.file("extdata", "handbook", "index.html", package = "FormIOr")
# browseURL(handbook)

