library(testthat)
library(FormIOr)

test_check("FormIOr")
